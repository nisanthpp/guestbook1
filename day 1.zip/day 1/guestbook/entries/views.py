from django.shortcuts import render, redirect
from .models import Entry
from .forms import EntryForm

def guestbook_view(request):
    if request.method == 'POST':
        form = EntryForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('guestbook')
    else:
        form = EntryForm()
    entries = Entry.objects.all().order_by('-created_at')
    return render(request, 'entries/guestbook.html', {'form': form, 'entries': entries})
